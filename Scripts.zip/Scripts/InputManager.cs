using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class InputManager : MonoBehaviour
{
    // Delegate that we will call when we click first time in our map
    // OnMouseHold used when we want to create a road and to find the shortest path from the start point
    // to the point where we are currently holding our mouse and recalculate our new path
    public Action<Vector3Int> OnMouseClick, OnMouseHold;
    // To know when the player stops pressing the mouse button
    public Action OnMouseUp;
    // We need to move our camera
    private Vector2 _cameraMovementVector;

    // Serialize the field to be able to assign Camera to the inspector
    [SerializeField]
    // We need to access the Camera object
    Camera mainCamera;

    // Let the InputManager decide if we click the correct map or layer on the map
    // if no click happened then no need to send the onclick event
    public LayerMask groundMask;

    public Vector2 CameraMovementVector
    {
        get { return _cameraMovementVector; }
        // We don't need to set the value.  We only need to read it.
        //set { _cameraMovementVector = value; } 
    }

    // Get all the input from the player
    private void Update()
    {
        CheckClickDownEvent();
        CheckClickUpEvent();
        CheckClickHoldEvent();
        CheckArrowInput();
    }

    // This method Raycast our ground to see if we have position or not
    private Vector3Int? RaycastGround()
    {
        RaycastHit hit;
        // This create a ray from the camera towards the point where we hit the mouse in our scene
        Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
        if(Physics.Raycast(ray, out hit, Mathf.Infinity, groundMask))
        {
            // Create Vector3Int to compare its position easily
            Vector3Int positionInt = Vector3Int.RoundToInt(hit.point);
            return positionInt;
        }
        // This means that we didn't hit the ground
        return null;
    }

    private void CheckArrowInput()
    {
        _cameraMovementVector = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical")); // Horizontal key: A and D, Arrow Left and Arrow Right
    }

    private void CheckClickHoldEvent()
    {
        // If mouse button is held and check if our pointer is not over of game object UI
        if (Input.GetMouseButton(0) && EventSystem.current.IsPointerOverGameObject() == false)
        {
            var position = RaycastGround();
            if (position != null)
            {
                OnMouseHold?.Invoke(position.Value);
            }
        }
    }

    private void CheckClickUpEvent()
    {
        // If mouse button is held and check if our pointer is not over of game object UI
        if (Input.GetMouseButtonUp(0) && EventSystem.current.IsPointerOverGameObject() == false)
        {
            var position = RaycastGround();
            if (position != null)
            {
                OnMouseUp?.Invoke();
            }
        }
    }

    private void CheckClickDownEvent()
    {
        // If mouse button is held and check if our pointer is not over of game object UI
        if (Input.GetMouseButtonDown(0) && EventSystem.current.IsPointerOverGameObject() == false)
        {
            var position = RaycastGround();
            if (position != null)
            {
                OnMouseClick?.Invoke(position.Value);
            }
        }
    }
}
