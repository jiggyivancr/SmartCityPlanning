using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIController : MonoBehaviour
{
    public Action OnRoadPlacement, OnHousePlacement, OnSpecialPlacement, OnBigStructurePlacement, OnShowScore, OnAICityDesign;
    public Button placeRoadButton, placeHouseButton, placeSpecialButton, placeBigStructureButton, showScoreButton, showAIDesignButton;

    public Color outlineColor;
    List<Button> buttonList;

    private void Start()
    {
        buttonList = new List<Button>() { placeHouseButton, placeRoadButton, placeSpecialButton, placeBigStructureButton, showScoreButton, showAIDesignButton };

        placeRoadButton.onClick.AddListener(() => 
        {
            ResetButtonColor();
            ModifyOutline(placeRoadButton);
            OnRoadPlacement?.Invoke();
        });
        placeHouseButton.onClick.AddListener(() =>
        {
            ResetButtonColor();
            ModifyOutline(placeHouseButton);
            OnHousePlacement?.Invoke();
        });
        placeSpecialButton.onClick.AddListener(() =>
        {
            ResetButtonColor();
            ModifyOutline(placeSpecialButton);
            OnSpecialPlacement?.Invoke();
        });
        placeBigStructureButton.onClick.AddListener(() =>
        {
            ResetButtonColor();
            ModifyOutline(placeBigStructureButton);
            OnBigStructurePlacement?.Invoke();
        });
        showScoreButton.onClick.AddListener(() =>
        {
            ResetButtonColor();
            ModifyOutline(showScoreButton);
            OnShowScore?.Invoke();
        });
        showAIDesignButton.onClick.AddListener(() =>
        {
            ResetButtonColor();
            ModifyOutline(showAIDesignButton);
            OnAICityDesign?.Invoke();
        });
    }

    private void ModifyOutline(Button button)
    {
        var outline = button.GetComponent<Outline>();
        outline.effectColor = outlineColor;
        outline.enabled = true;
    }

    private void ResetButtonColor()
    {
        foreach (Button button in buttonList)
        {
            button.GetComponent<Outline>().enabled = false;
        }
    }
}
