﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RuleManager : MonoBehaviour
{
    //Player starts with level 1 task: 6 Houses + 2 Shops.
    //Once player finishes level 1 task, a reward will be given. one reward for completing level1 could be: 
    //7-electric - Energy Generating Floor.
    //The reward to completing level2 is: 2 wind turbine.
    //The reward to completing level3 is: an electric car and car charger.

    public List<CellType> get_level1_task()
    {
        List<CellType> l1task = new List<CellType>();
        l1task.Add(CellType.Structure);
        l1task.Add(CellType.Structure);
        l1task.Add(CellType.Structure);
        l1task.Add(CellType.Structure);
        l1task.Add(CellType.Structure);
        l1task.Add(CellType.Structure);
        l1task.Add(CellType.SpecialStructure);
        l1task.Add(CellType.SpecialStructure);
        return l1task;
    }

    //More Buildings
    //public List<CellType> get_level2_task()
    //{
    //    List<CellType> l2task = new List<CellType>();
    //    l1task.Add(CellType.Structure);
    //    l1task.Add(CellType.Structure);
    //    l1task.Add(CellType.Structure);
    //    l1task.Add(CellType.Structure);
    //    l1task.Add(CellType.Structure);
    //    l1task.Add(CellType.Structure);
    //    l1task.Add(CellType.Structure);

    //    l1task.Add(CellType.SpecialStructure);
    //    l1task.Add(CellType.SpecialStructure);
    //    return l2task;
    //}
}