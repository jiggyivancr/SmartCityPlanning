﻿using System;
using System.Collections.Generic;
using UnityEngine;
using System.Linq; //For calculating standard deviation (std).

public class Individual
{
    public Dictionary<Vector3Int, CellType> gene { get; set; }
    public double fitness { get; set; }
}

public class GA : MonoBehaviour
{
    public ScoreManager scoreManager = new ScoreManager();
    public RuleManager ruleManager = new RuleManager();

    List<CellType> list_obj_types = new List<CellType>();

    public double fitness(double std, double avg)
    {
        return ((1 / (std + 10)) * avg);
    }

    //Genetic Algorithm (GA)
    //SizeGrid = 15*15 Grid = 225 Max SizeGrid
    public int N { get; set; } //Length of Gene
    public int P { get; set; } //Population Size
    public int T { get; set; } //Tournament Selection PK Size
    public int G { get; set; } //Generation
    public int MUTRATE { get; set; } //Mutation Rate
    public int SizeGrid { get; set; } //Grid Size

    //Array of Individuals.
    public List<Individual> population = new List<Individual>();
    public List<Individual> offspring = new List<Individual>();
    public List<double> meanfit = new List<double>();
    public List<double> bestfit = new List<double>();
    public Dictionary<Vector3Int, CellType> aiposTypeDicBest = new Dictionary<Vector3Int, CellType>();//For AI.

    public double fit1(Individual ind)// todo: call the score function
    {
        //from ind get aiposTypeDicBest
       // Debug.Log("ind.gene.Count: " + ind.gene.Count);
        aiposTypeDicBest = ind.gene;
        //Debug.Log("aiposTypeDicBest.Count: " + aiposTypeDicBest.Count);
        double fitness = 0;
        fitness = scoreManager.calculateScore4ai(aiposTypeDicBest);//need position and type

        return fitness;
    }

    public void init()
    {
        System.Random rnd = new System.Random();
        for (int i = 0; i < P; i++)
        {
            Individual tmpind = new Individual();
            Dictionary<Vector3Int, CellType> tmpgene = new Dictionary<Vector3Int, CellType>();
            for (int j = 0; j < N; j++)
            {
                int pos = rnd.Next(0, SizeGrid);//Hard coded SizeGrid. 
                Vector3Int vpos = convertidx2v3(pos);
                if (!tmpgene.ContainsKey(vpos))
                {
                    tmpgene[vpos] = list_obj_types[j];
                }
                else
                {
                    while (tmpgene.ContainsKey(vpos))
                    {
                        pos = rnd.Next(0, SizeGrid);
                        vpos = convertidx2v3(pos);
                    }
                    tmpgene[vpos] = list_obj_types[j];
                }
            }
            tmpind.gene = tmpgene;
            tmpind.fitness = fit1(tmpind);
            population.Add(tmpind);
        }
        //==========================init offspring=====================
        for (int i = 0; i < P; i++)
        {
            Individual tmpind = new Individual();
            Dictionary<Vector3Int, CellType> tmpgene = new Dictionary<Vector3Int, CellType>();
            for (int j = 0; j < N; j++)
            {
                int pos = rnd.Next(0, SizeGrid);//hard coded SizeGrid 
                Vector3Int vpos = convertidx2v3(pos);
                if (!tmpgene.ContainsKey(vpos))
                {
                    tmpgene[vpos] = list_obj_types[j];
                }
                else
                {
                    while (tmpgene.ContainsKey(vpos))
                    {
                        pos = rnd.Next(0, SizeGrid);
                        vpos = convertidx2v3(pos);
                    }
                    tmpgene[vpos] = list_obj_types[j];
                }
            }
            tmpind.gene = tmpgene;
            tmpind.fitness = fit1(tmpind);
            offspring.Add(tmpind);
        }
    }

    public void selection()
    {
        System.Random rnd = new System.Random();
        for (int i = 0; i < P; i++)
        {
            int parent1 = rnd.Next(0, P);//parent1's index
            int parent2 = rnd.Next(0, P);
            //Debug.Log("before offspring[i].fitness: " + offspring[i].fitness);
            if (population[parent1].fitness > population[parent2].fitness)
                offspring[i] = population[parent1];
            else
                offspring[i] = population[parent2];
            //Debug.Log("after offspring[i].fitness: " + offspring[i].fitness);
        }
    }

    public void xover1()
    {//after crossover, the total_fit of this pop stays the same
        System.Random rnd = new System.Random();
        int pos = 0;
        for (int i = 0; i < P; i += 2)
        {
            Individual temp = offspring[i];
            int crosspoint = rnd.Next(0, N);
            for (int j = crosspoint; j < N; j++)
            {
                Vector3Int exchangedkey_0 = offspring[i].gene.ElementAt(j).Key;
                CellType ct0 = offspring[i].gene.ElementAt(j).Value;
                Vector3Int exchangedkey_1 = offspring[i + 1].gene.ElementAt(j).Key;
                CellType ct1 = offspring[i + 1].gene.ElementAt(j).Value;

                //before exchange key, validate
                if (!offspring[i].gene.ContainsKey(exchangedkey_1))
                {
                    offspring[i].gene[exchangedkey_1] = ct0;//keep the value
                }
                else
                {
                    while (offspring[i].gene.ContainsKey(exchangedkey_1))
                    { pos = rnd.Next(0, SizeGrid); exchangedkey_1 = convertidx2v3(pos); }
                    offspring[i].gene[exchangedkey_1] = ct0;
                }

                if (!offspring[i + 1].gene.ContainsKey(exchangedkey_0))
                {
                    offspring[i + 1].gene[exchangedkey_0] = ct1;//keep the value
                }
                else
                {
                    while (offspring[i + 1].gene.ContainsKey(exchangedkey_0))
                    { pos = rnd.Next(0, SizeGrid); exchangedkey_0 = convertidx2v3(pos); }
                    offspring[i + 1].gene[exchangedkey_0] = ct1;
                }
            }
            offspring[i].fitness = fit1(offspring[i]);//we need to update the Individual's fitness
            offspring[i + 1].fitness = fit1(offspring[i + 1]);//we need to update the Individual's fitness
        }
    }

    public void mutation()
    {
        System.Random rnd = new System.Random();
        int pos = 0;
        for (int i = 0; i < P; i++)
        {
            for (int j = 0; j < N; j++)
            {
                if (rnd.Next(0, 100) < MUTRATE)
                {
                    CellType ct0 = offspring[i].gene.ElementAt(j).Value;

                    Vector3Int new_pos = offspring[i].gene.ElementAt(j).Key;
                    //define mutation step:
                    //here the mutation step = 1
                    if (rnd.Next(0, 5) == 0 && (new_pos.x + 1) < 15)
                    {
                        new_pos.x = new_pos.x + 1;
                    }
                    else if (rnd.Next(0, 5) == 1 && (new_pos.x - 1) >= 0)
                    {
                        new_pos.x = new_pos.x - 1;
                    }
                    else if (rnd.Next(0, 5) == 2 && (new_pos.z + 1) < 15)
                    {
                        new_pos.z = new_pos.z + 1;
                    }
                    else if (rnd.Next(0, 5) == 3 && (new_pos.z - 1) >= 0)
                    {
                        new_pos.z = new_pos.z - 1;
                    }

                    if (!offspring[i].gene.ContainsKey(new_pos))
                    {
                        offspring[i].gene[new_pos] = ct0;//keep the value
                    }
                    else
                    {
                        while (offspring[i].gene.ContainsKey(new_pos))
                        //the strategy is MUST mutate. 
                        //another strategy is do not change if there is conflict
                        { pos = rnd.Next(0, SizeGrid); new_pos = convertidx2v3(pos); }
                        offspring[i].gene[new_pos] = ct0;
                    }
                }
            }
            offspring[i].fitness = fit1(offspring[i]);//after mutation, the Individual fitness changed
        }
    }

    public double totalfit(List<Individual> pop)
    {
        double totfit = 0;
        for (int i = 0; i < P; i++)
        {
            totfit += pop[i].fitness;
        }
        return totfit;
    }

    public void updatepop()
    {
        for (int i = 0; i < P; i++)
        {
            for (int j = 0; j < N; j++)
            {
                Vector3Int k_off = offspring[i].gene.ElementAt(j).Key;
                CellType ct_off = offspring[i].gene.ElementAt(j).Value;
                population[i].gene[k_off] = ct_off;
            }
            population[i].fitness = offspring[i].fitness;
        }
    }

    public List<int> get_valid_pos(List<int> fullpos, List<int> occupiedpos)//todo
    {
        List<int> result = new List<int>();
        return result;
    }

    public Individual getbest_individual()
    {
        //runGA
        runGA();
        //Compute Best
        double bestfit = 0;
        int best_idx = 0;
        for (int j = 0; j < P; j++)
        {
            if (population[j].fitness > bestfit)
            {
                bestfit = population[j].fitness;
                best_idx = j;
            }
        }
        return population[best_idx];
    }

    public Vector3Int convertidx2v3(int i)
    {
        //Get x (Column)
        int x = i / 15; //Hard coded.
        //Get z (Row)
        int z = i % 15;
        Vector3Int result = new Vector3Int(x, 0, z);
        return result;
    }

    public Dictionary<Vector3Int, CellType> get_best()
    {
        list_obj_types = ruleManager.get_level1_task();
        Dictionary<Vector3Int, CellType> result = new Dictionary<Vector3Int, CellType>();
        Individual best_ind = getbest_individual();//this should be returned by runGA
        N = list_obj_types.Count();
        System.Random rnd = new System.Random();
        int pos = 0;
        for (int i = 0; i < N; i++)
        {
            Vector3Int vpos = best_ind.gene.ElementAt(i).Key;
            if (!result.ContainsKey(vpos))
            { result[vpos] = list_obj_types[i]; }//or, result[vpos] = best_ind.gene.ElementAt(i).Value;
            else
            {
                while (result.ContainsKey(vpos))
                { pos = rnd.Next(0, SizeGrid); vpos = convertidx2v3(pos); }
                result[vpos] = list_obj_types[i];
            }

        }
        return result;
    }
    // start: GA simulation===========================================
    public void runGA()
    {
        //init params: 
        N = list_obj_types.Count();
        //Debug.Log("N:     "+N);
        P = 4; //Population Size
        T = 2; //Tournament Selection PK Size
        G = 3; //Generation
        MUTRATE = 2; //Mutation Rate
        SizeGrid = 105;
        //SizeGrid = 113; //More space for AI. Unfair for player.

        //init pop
        //selection for mating-pool
        //xover
        //mutation
        //selection
        //update pop

        init();
        for (int i = 0; i < G; i++)
        {

            selection();
            xover1();
            mutation();
            selection();
            updatepop();
            Debug.Log("meanfitness: "+totalfit(population)/P);
        }
    }
    //End of Genetic Algorithm
}