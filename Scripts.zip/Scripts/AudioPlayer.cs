﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SVS

{
    public class AudioPlayer : MonoBehaviour
    {
        public AudioClip placementSound;
        public AudioSource audioSource;

        public static AudioPlayer instance;

        private void Awake()
        {
            if (instance == null)
                instance = this;
            else if (instance != this)
                Destroy(this.gameObject);
        }

        //Plays sound effect when the user places down an object on the terrain.
        public void PlayPlacementSound()
        {
            if(placementSound != null)
            {
                audioSource.PlayOneShot(placementSound);
            }
        }
    }
}