using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneChanger : MonoBehaviour
{
    public GameObject pauseMenuUI; //Uses pause menu from Unity editor after it is assigned.
    
    public static bool GameIsPaused = false;

    //Directs to the next scene using the scenes stored in the build setting list.
    public void ChangeScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    //Directs to the main menu. Main menu scene index is 1.
    public void MainMenuScene()
    {
        SceneManager.LoadScene(1);
    }

    //Closes the application.
    public void QuitGame()
    {
        Debug.Log("----------THE USER HAS EXIT THE GAME----------");
        Application.Quit();
    }

    //Changes the game environment.
    public void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (GameIsPaused)
            {
                Resume();
            }
            else
            {
                Pause();
            }
        }
    }

    //Continues the game.
    public void Resume()
    {
        pauseMenuUI.SetActive(false);
        //Time.timeScale = 1f; //Unfreezes the game.
        GameIsPaused = false;
    }

    //Pauses the game.
    void Pause()
    {
        pauseMenuUI.SetActive(true);
        //Time.timeScale = 0f; //Freezes the game.
        GameIsPaused = true;
    }
}