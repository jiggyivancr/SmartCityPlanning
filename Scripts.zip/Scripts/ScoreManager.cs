﻿using SVS;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ScoreManager : MonoBehaviour
{
   public PlacementManager placementManager;
   // public AIEngine aiEngine;
    float s = 0;
    //basic:
    //public RuleManager ruleManager = new RuleManager();// added

    //=====================for calculating score====================================
    public List<Vector3Int> list_pos_structure = new List<Vector3Int>();// added; house; resident_living
    public List<Vector3Int> list_pos_road = new List<Vector3Int>();// added
    public List<Vector3Int> list_pos_special = new List<Vector3Int>();// added
    public List<Vector3Int> list_pos_ele = new List<Vector3Int>();// added
    public List<Vector3Int> list_pos_turbine = new List<Vector3Int>();// added


   // public List<CellType> list_obj_types = new List<CellType>();
    private void Start()
    {
        Debug.Log("Start ScoreManager.");
    }

    /*// added
    public void ShowScore(Vector3Int position)
    {
        Debug.Log("in showscore func. Current position: " + position);
        Debug.Log("Call placementManager.Fitness: " + placementManager.Fitness());        
    }*/

    //===============================bellow : AI=================================================================
    public double fitness(double std, double avg)
    {
        return ((1 / (std + 10)) * avg);
    }

    public double calculateScore4human()//should be put in scoremanager
    {

        list_pos_structure.Clear();
        list_pos_road.Clear();
        list_pos_special.Clear();
        list_pos_ele.Clear();
        list_pos_turbine.Clear();
        //maximization
        //formula: a1*(1/std)+a2*(avg(house_to_others_distance))+a3*(total_electricity)+a4*(1/total_connection_distance)+a5*(total_noise)
        //std: evaluate distance between each house and its nearest shop ()
        //house_to_others_distance: get the 8 neighbores position. evaluate the overall comfertable ? what's the literature for this?
        //total_electricity = n_t*turbine+n_e*elec_tiles
        //total_noise=b1*(1/(n_t*turbine))+b2*(1/avg(distance_between_turbine_and_its_neighbore))
        //1/std
        foreach (KeyValuePair<Vector3Int, CellType> entry in placementManager.posTypeDic)
        {
            get_position_by_type(entry);//fill the list_of_pos by type
        }
        Dictionary<Vector3Int, double> dic_short_between_resi_shop = get_dic_pos_shortest(list_pos_structure, list_pos_special);
        double std = cal_std(dic_short_between_resi_shop);
        double avg_between_resi = cal_avg_resi(list_pos_structure, list_pos_structure);
        //Debug.Log("score of std: " + (std));
        //Debug.Log("score of avg_between_resi: " + (avg_between_resi));
        //Debug.Log("score of (1/(std+0.000000001))*avg_between_resi: " + (1 / (std + 0.000000001)) * avg_between_resi);//bad: could be very large if std is 0
        return fitness(std, avg_between_resi);
    }
    public double calculateScore4ai(Dictionary<Vector3Int, CellType> aiposTypeDicBest)
    {
        list_pos_structure.Clear();
        list_pos_road.Clear();
        list_pos_special.Clear();
        list_pos_ele.Clear();
        list_pos_turbine.Clear();
        //maximization
        //formula: a1*(1/std)+a2*(avg(house_to_others_distance))+a3*(total_electricity)+a4*(1/total_connection_distance)+a5*(total_noise)
        //std: evaluate distance between each house and its nearest shop ()
        //house_to_others_distance: get the 8 neighbores position. evaluate the overall comfertable ? what's the literature for this?
        //total_electricity = n_t*turbine+n_e*elec_tiles
        //total_noise=b1*(1/(n_t*turbine))+b2*(1/avg(distance_between_turbine_and_its_neighbore))
        //1/std
        foreach (KeyValuePair<Vector3Int, CellType> entry in aiposTypeDicBest)
        {
            get_position_by_type(entry);//fill the list_of_pos by type
        }
        Dictionary<Vector3Int, double> dic_short_between_resi_shop = get_dic_pos_shortest(list_pos_structure, list_pos_special);
        double std = cal_std(dic_short_between_resi_shop);
        double avg_between_resi = cal_avg_resi(list_pos_structure, list_pos_structure);
        //Debug.Log("score of std: " + (std));
        //Debug.Log("score of avg_between_resi: " + (avg_between_resi));
        //Debug.Log("score of (1/(std+0.000000001))*avg_between_resi: " + (1 / (std + 0.000000001)) * avg_between_resi);//bad: could be very large if std is 0
        return fitness(std, avg_between_resi);
    }
    //end basic
    //seperate the objects by type, resulted in list of positions
    public void get_position_by_type(KeyValuePair<Vector3Int, CellType> entry)
    {
        Vector3Int position = entry.Key;
        if (entry.Value == CellType.Structure)//house or flat
        {
            list_pos_structure.Add(position);
        }
        else if (entry.Value == CellType.SpecialStructure)//shop or school or other public services
        {
            list_pos_special.Add(position);
        }
        //else if (entry.Value == CellType.Turbine)//Turbine
        //{
        //    list_pos_turbine.Add(position);
        //}
        //else if (entry.Value == CellType.ElePavement)//ElePavement
        //{
        //    list_pos_ele.Add(position);
        //}
        else if (entry.Value == CellType.Road)//Road
        {
            list_pos_road.Add(position);
        }
    }

    //: dic_pos_shortest
    public Dictionary<Vector3Int, double> get_dic_pos_shortest(List<Vector3Int> list_pos1, List<Vector3Int> list_pos2)
    {
        Dictionary<Vector3Int, double> dic_pos_shortest = new Dictionary<Vector3Int, double>();
        foreach (Vector3Int resi_pos in list_pos1)//for every residential house/flat
        {
            double shortdist = 1000000;
            foreach (Vector3Int sp_pos in list_pos2)//for every shop or public service 
            {
                if (Vector3.Distance(resi_pos, sp_pos) < shortdist)
                {
                    shortdist = Vector3.Distance(resi_pos, sp_pos);
                }
            }
            dic_pos_shortest[resi_pos] = shortdist;
        }
        return dic_pos_shortest;
    }

    public double cal_std(Dictionary<Vector3Int, double> dic_pos_dist)
    {
        IEnumerable<double> ien_dist;
        List<double> list_dist = new List<double>();
        double standardDeviation = 0.00001;
        foreach (KeyValuePair<Vector3Int, double> entry in dic_pos_dist)
        {
            list_dist.Add(entry.Value);
        }
        ien_dist = list_dist;
        if (list_dist.Count > 0)
        {
            // Compute the average.     
            double avg = ien_dist.Average();

            // Perform the Sum of (value-avg)_2_2.      
            double sum = ien_dist.Sum(d => Math.Pow(d - avg, 2));

            // Put it all together.      
            standardDeviation = Math.Sqrt((sum) / (ien_dist.Count() - 1));
            //Debug.Log("standardDeviation: " + standardDeviation);
        }
        return standardDeviation;
    }

    public double cal_avg_resi(List<Vector3Int> list_pos1, List<Vector3Int> list_pos2)
    {
        double avg = 0;
        foreach (Vector3Int resi_pos in list_pos1)//for every residential house/flat
        {
            foreach (Vector3Int sp_pos in list_pos2)//for every shop or public service 
            {
                avg = avg + Vector3.Distance(resi_pos, sp_pos);
            }
        }
        avg = (double)avg / ((list_pos1.Count - 1) * (list_pos2.Count));
        return avg;
    }

}
