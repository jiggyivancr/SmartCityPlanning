using SVS;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public CameraMovement cameraMovement;
    public InputManager inputManager;
    public RoadManager roadManager;
    public UIController uiController;
    public StructureManager structureManager;
    public ScoreManager scoreManager;
    public PlacementManager placementManager;
    public GA gA = new GA();
    public Dictionary<Vector3Int, CellType> best_ai_plan = new Dictionary<Vector3Int, CellType>();
    public GameObject structurePrefab;
    public GameObject specialPrefab;

    private void Start()
    {
        uiController.OnRoadPlacement += RoadPlacementHandler;
        uiController.OnHousePlacement += HousePlacementHandler;
        uiController.OnSpecialPlacement += SpecialPlacementHandler;
        uiController.OnBigStructurePlacement += BigStructurePlacementHandler;
        uiController.OnShowScore += ShowScoreHandler;
        uiController.OnAICityDesign += AICityDesignHandler;
    }

    private void BigStructurePlacementHandler()
    {
        ClearInputActions();
        inputManager.OnMouseClick += structureManager.PlaceBigStructure;
    }

    private void SpecialPlacementHandler()
    {
        ClearInputActions();
        inputManager.OnMouseClick += structureManager.PlaceSpecial;
    }

    private void HousePlacementHandler()
    {
        ClearInputActions();
        inputManager.OnMouseClick += structureManager.PlaceHouse;
    }

    private void RoadPlacementHandler()
    {
        ClearInputActions();
        inputManager.OnMouseClick += roadManager.PlaceRoad;
        inputManager.OnMouseHold += roadManager.PlaceRoad;
        inputManager.OnMouseUp += roadManager.FinishPlacingRoad;
    }

    private void ShowScoreHandler()
    {
        ClearInputActions();
        Debug.Log("--------SHOW SCORE HANDLER---------");
        Debug.Log("HUMAN SCORE: " + scoreManager.calculateScore4human());
        Debug.Log("AI SCORE: " + scoreManager.calculateScore4ai(gA.aiposTypeDicBest));
    }

    private void AICityDesignHandler()
    {
        best_ai_plan = gA.get_best();
        //clear existing buildings designed by human
        if (placementManager.posTypeDic.Count > 0)//todo: make sure posTypeDic includes everything
        {
            foreach (KeyValuePair<Vector3Int, CellType> entry in placementManager.posTypeDic)
            {
                //position: entry.Key
                placementManager.DestroyNatureAt(entry.Key);//todo: destroy doesn't work

            }
        }

        //clear existing buildings designed by AI
        if (best_ai_plan.Count > 0)
        {
            foreach (KeyValuePair<Vector3Int, CellType> entry in best_ai_plan)
            {
                //position: entry.Key
                placementManager.DestroyNatureAt(entry.Key);

            }
        }


        //DestroyNatureAt(Vector3Int position)
        //step 1: grab the total GameObjects to be placed

        //Debug.Log("list_obj_types count: " + list_obj_types.Count);
        //step 2: use GA to generate the optimized positions for each object. 
        //step 2.1: derive fitness formula based on literature review
        //step 2.2: create a subfunction to verify the individual (individual must satisfy some constrains)
        ClearInputActions();
        Debug.Log("in GameManager aiPlacementHandler: ");
        //: get the dictionary, <int, Vector3Int>, int is the object index
        //the length of Gene is N = placementManager.listObj.Count();
        //the value of the Gene should within 112 (have of the Grid), or could be full, depends

        //runGA, return the best
        /*list_obj_types = ruleManager.get_level1_task();*/
        best_ai_plan = gA.get_best();
        //Debug.Log("best_ai_plan.Count: " + best_ai_plan.Count);

        foreach (KeyValuePair<Vector3Int, CellType> entry in best_ai_plan)
        {
            // Debug.Log("entry.Value: " + entry.Value);
            // Debug.Log("entry.Key: " + entry.Key);
            GameObject gobj = new GameObject();
            if (entry.Value == CellType.Structure)
            {
                gobj = structurePrefab;
            }
            else if (entry.Value == CellType.SpecialStructure)
            {
                gobj = specialPrefab;
            }
            //else if (entry.Value == CellType.Turbine)
            //{
            //    gobj = turbinePrefab;
            //}
            placementManager.PlaceObjectOnTheMap(entry.Key, gobj, entry.Value, 0);
        }

    }

    private void ClearInputActions()
    {
        inputManager.OnMouseClick = null;
        inputManager.OnMouseHold = null;
        inputManager.OnMouseUp = null;
    }

    //private void HandleMouseClick(Vector3Int position)
    //{
    //    Debug.Log(position);
    //    roadManager.PlaceRoad(position);
    //}

    private void Update()
    {
        cameraMovement.MoveCamera(new Vector3(inputManager.CameraMovementVector.x, 0, inputManager.CameraMovementVector.y));
    }
}
