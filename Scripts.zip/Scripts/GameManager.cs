using SVS;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public CameraMovement cameraMovement;
    public InputManager inputManager;
    public RoadManager roadManager;
    public UIController uiController;
    public StructureManager structureManager;
    public ScoreManager scoreManager;
    public PlacementManager placementManager;
    
    public GA gA = new GA();
    
    public GameObject structurePrefab;
    public GameObject specialPrefab;
    
    public Dictionary<Vector3Int, CellType> best_ai_plan = new Dictionary<Vector3Int, CellType>();

    //Handles the type of object placed on the terrain using the buttons from the menu.
    private void Start()
    {
        uiController.OnRoadPlacement += RoadPlacementHandler;
        uiController.OnHousePlacement += HousePlacementHandler;
        uiController.OnSpecialPlacement += SpecialPlacementHandler;
        uiController.OnBigStructurePlacement += BigStructurePlacementHandler;
        uiController.OnShowScore += ShowScoreHandler;
        uiController.OnAICityDesign += AICityDesignHandler;
    }

    private void BigStructurePlacementHandler()
    {
        ClearInputActions();
        inputManager.OnMouseClick += structureManager.PlaceBigStructure;
    }

    private void SpecialPlacementHandler()
    {
        ClearInputActions();
        inputManager.OnMouseClick += structureManager.PlaceSpecial;
    }

    private void HousePlacementHandler()
    {
        ClearInputActions();
        inputManager.OnMouseClick += structureManager.PlaceHouse;
    }

    private void RoadPlacementHandler()
    {
        ClearInputActions();
        inputManager.OnMouseClick += roadManager.PlaceRoad;
        inputManager.OnMouseHold += roadManager.PlaceRoad;
        inputManager.OnMouseUp += roadManager.FinishPlacingRoad;
    }

    private void ShowScoreHandler()
    {
        ClearInputActions();
        Debug.Log("----------SHOW SCORE HANDLER----------"); //Check if the method is called.
        Debug.Log("HUMAN SCORE: " + scoreManager.calculateScore4human());
        Debug.Log("AI SCORE: " + scoreManager.calculateScore4ai(gA.aiposTypeDicBest));
    }

    private void AICityDesignHandler()
    {
        best_ai_plan = gA.get_best();

        //Clear existing buildings designed by human.
        if (placementManager.posTypeDic.Count > 0)//TODO: make sure posTypeDic includes everything.
        {
            foreach (KeyValuePair<Vector3Int, CellType> entry in placementManager.posTypeDic)
            {
                //Position: entry.Key
                placementManager.DestroyNatureAt(entry.Key);//TODO: Destroy does not work.
            }
        }

        //Clear existing buildings designed by AI.
        if (best_ai_plan.Count > 0)
        {
            foreach (KeyValuePair<Vector3Int, CellType> entry in best_ai_plan)
            {
                //Position: entry.Key.
                placementManager.DestroyNatureAt(entry.Key);
            }
        }

        //DestroyNatureAt(Vector3Int position)
        //Step 1: Grab the total GameObjects to be placed.
        //Debug.Log("list_obj_types count: " + list_obj_types.Count);
        //Step 2: Use GA to generate the optimized positions for each object. 
        //Step 2.1: Derive fitness formula based on literature review.
        //Step 2.2: Create a subfunction to verify the Individual (Individual must satisfy some constrains).
        ClearInputActions();
        //Debug.Log("in GameManager aiPlacementHandler: ");
        //Get the dictionary, <int, Vector3Int>, int is the object index.
        //The length of Gene is N = placementManager.listObj.Count();
        //The value of the Gene should within (7*15) 105 (half of the grid, removing the middle to be equal for AI and player).
        //runGA, return the best.

        //list_obj_types = ruleManager.get_level1_task(); //Places certain objects based from rules in RuleManager.
        best_ai_plan = gA.get_best();
        //Debug.Log("best_ai_plan.Count: " + best_ai_plan.Count);

        foreach (KeyValuePair<Vector3Int, CellType> entry in best_ai_plan)
        {
            //Debug.Log("entry.Value: " + entry.Value);
            //Debug.Log("entry.Key: " + entry.Key);
            GameObject gobj = new GameObject();
            if (entry.Value == CellType.Structure)
            {
                gobj = structurePrefab;
            }
            else if (entry.Value == CellType.SpecialStructure)
            {
                gobj = specialPrefab;
            }
            //else if (entry.Value == CellType.Turbine)
            //{
            //    gobj = turbinePrefab;
            //}
            placementManager.PlaceObjectOnTheMap(entry.Key, gobj, entry.Value, 0);
        }
    }

    private void ClearInputActions()
    {
        inputManager.OnMouseClick = null;
        inputManager.OnMouseHold = null;
        inputManager.OnMouseUp = null;
    }

    private void Update()
    {
        cameraMovement.MoveCamera(new Vector3(inputManager.CameraMovementVector.x, 0, inputManager.CameraMovementVector.y));
    }
}